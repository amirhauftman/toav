import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

export interface User {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export interface Tag {
  id: string;
  name: string;
  description?: string;
}

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
});

class AuthService {
  private user: User | null = null;
  private token: string | null = localStorage.getItem('token');

  constructor() {
    this.loadUserFromToken();
  }

  private setAuthToken(token: string | null) {
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      console.log('Set Authorization header:', `Bearer ${token}`); // Debug
    } else {
      delete api.defaults.headers.common['Authorization'];
    }
  }

  private loadUserFromToken() {
    if (this.token) {
      try {
        const decoded = jwtDecode<{ sub: string; email: string; role: string }>(this.token);
        this.user = {
          id: decoded.sub,
          name: '', // Populate from backend if available
          email: decoded.email,
          role: decoded.role,
        };
        this.setAuthToken(this.token);
      } catch (err) {
        console.error('Invalid token:', err);
        this.logout();
      }
    }
  }

  async login(email: string, password: string): Promise<void> {
    try {
      const response = await api.post<AuthResponse>('/auth/login', { email, password });
      const { user, token } = response.data;
      this.user = user;
      this.token = token;
      localStorage.setItem('token', token);
      this.setAuthToken(token);
    } catch (err: any) {
      console.error('Login error:', err.response?.data?.message || err.message);
      throw new Error(err.response?.data?.message || 'Login failed');
    }
  }

  async register(name: string, email: string, password: string, role?: string): Promise<void> {
    try {
      const response = await api.post<AuthResponse>('/auth/register', { name, email, password, role });
      const { user, token } = response.data;
      this.user = user;
      this.token = token;
      localStorage.setItem('token', token);
      this.setAuthToken(token);
    } catch (err: any) {
      console.error('Register error:', err.response?.data?.message || err.message);
      throw new Error(err.response?.data?.message || 'Registration failed');
    }
  }

  async getTags(): Promise<Tag[]> {
    try {
      const response = await api.get<Tag[]>('/tags');
      return response.data;
    } catch (err: any) {
      console.error('Get tags error:', err.response?.data?.message || err.message);
      throw new Error(err.response?.data?.message || 'Failed to fetch tags');
    }
  }

  logout(): void {
    this.user = null;
    this.token = null;
    localStorage.removeItem('token');
    this.setAuthToken(null);
  }

  getUser(): User | null {
    return this.user;
  }

  getToken(): string | null {
    return this.token;
  }
}

export const authService = new AuthService();