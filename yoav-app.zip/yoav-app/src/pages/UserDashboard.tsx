import React, { useState } from 'react';
import {
  Box, Typography, Button, Grid, Paper, AppBar, Toolbar,
  Dialog, DialogTitle, DialogContent, DialogActions
} from '@mui/material';
import { useQueryClient } from '@tanstack/react-query';
import CallRecordList from '../components/user/CallRecordList';
import CallTaskList from '../components/user/CallTaskList';
import CallRecordForm from '../components/user/CallRecordForm';

const UserDashboard: React.FC = () => {
  const [selectedCallRecordId, setSelectedCallRecordId] = useState<string | null>(null);
  const [openForm, setOpenForm] = useState(false);
  const [editingRecord, setEditingRecord] = useState<{
    id: string;
    title: string;
    description?: string;
    callerName?: string;
    callerPhone?: string;
    status?: string;
    tagIds?: string[];
  } | null>(null);

  const queryClient = useQueryClient();

  const handleSelectCallRecord = (callRecordId: string) => {
    setSelectedCallRecordId(callRecordId);
  };

  const handleCreateNewCallRecord = () => {
    setEditingRecord(null);
    setOpenForm(true);
  };

  const handleEditCallRecord = (record: any) => {
    setEditingRecord(record);
    setOpenForm(true);
  };

  const handleRecordSaved = () => {
    queryClient.invalidateQueries({ queryKey: ['callRecords'] });
    setOpenForm(false);
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Call Management Dashboard
          </Typography>
          <Button color="inherit" onClick={handleCreateNewCallRecord}>
            Create New Call Record
          </Button>
        </Toolbar>
      </AppBar>

      <Box sx={{ p: 2 }}>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <Paper sx={{ p: 2, height: '80vh', overflow: 'auto' }}>
              <Typography variant="h6" gutterBottom>
                Open Call Records
              </Typography>
              <CallRecordList
                onSelectCallRecord={handleSelectCallRecord}
                onEditCallRecord={handleEditCallRecord}
                statusFilter="open"
              />
            </Paper>
          </Grid>

          <Grid item xs={6}>
            <Paper sx={{ p: 2, height: '80vh', overflow: 'auto' }}>
              <Typography variant="h6" gutterBottom>
                Task Details
              </Typography>
              {selectedCallRecordId ? (
                <CallTaskList callRecordId={selectedCallRecordId} />
              ) : (
                <Typography>Select a call record to view tasks.</Typography>
              )}
            </Paper>
          </Grid>
        </Grid>

        <Dialog open={openForm} onClose={() => setOpenForm(false)} maxWidth="md" fullWidth>
          <DialogTitle>{editingRecord ? 'Edit Call Record' : 'Create New Call Record'}</DialogTitle>
          <DialogContent>
            <CallRecordForm
              record={editingRecord}
              onClose={() => setOpenForm(false)}
              onSave={handleRecordSaved}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenForm(false)}>Cancel</Button>
          </DialogActions>
        </Dialog>
      </Box>
    </Box>
  );
};

export default UserDashboard;
