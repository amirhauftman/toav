import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Box, Typography, Button, TextField, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { getTags, createTag, deleteTag, updateTag } from '../api/tags'; // Adjust path
import type { Tag } from '../sevices/authService';

const AdminDashboard: React.FC = () => {
  const queryClient = useQueryClient();
  const [newTagName, setNewTagName] = useState('');
  const [newTagDescription, setNewTagDescription] = useState('');
  const [editTag, setEditTag] = useState<{ id: string; name: string; } | null>(null);

  const { data: tags = [], isLoading, error } = useQuery<Tag[]>({
    queryKey: ['tags'],
    queryFn: getTags,
  });

  const createMutation = useMutation({
    mutationFn: (variables: { name: string; description?: string }) => createTag(variables),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tags'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => deleteTag(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tags'] });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (variables: { id: string; name: string; }) => updateTag(variables.id, variables.name),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tags'] });
      setEditTag(null);
    },
  });

  const handleCreateTag = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim()) return;
    createMutation.mutate({ name: newTagName, description: newTagDescription || undefined });
    setNewTagName('');
    setNewTagDescription('');
  };

  const handleEditTag = (tag: Tag) => {
    setEditTag({ id: tag.id, name: tag.name, });
  };

  const handleSaveEdit = () => {
    if (editTag) {
      updateMutation.mutate({ id: editTag.id, name: editTag.name });
    }
  };

  const handleCancelEdit = () => {
    setEditTag(null);
  };

  if (isLoading) return <Typography>Loading...</Typography>;
  if (error) return <Typography color="error">Error: {error.message}</Typography>;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Admin Dashboard</Typography>
      <form onSubmit={handleCreateTag}>
        <TextField
          label="Tag Name"
          value={newTagName}
          onChange={(e) => setNewTagName(e.target.value)}
          sx={{ mb: 2, mr: 2 }}
          required
        />
        <Button type="submit" variant="contained" disabled={createMutation.isPending}>
          Create Tag
        </Button>
      </form>
      {createMutation.error && <Typography color="error">{createMutation.error.message}</Typography>}
      <Box sx={{ mt: 2 }}>
        <Typography variant="h6">Tags</Typography>
        {tags.map((tag: Tag) => (
          <Box key={tag.id} sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
            <Typography>{tag.name} </Typography>
            <Button
              variant="outlined"
              color="primary"
              onClick={() => handleEditTag(tag)}
              sx={{ ml: 2 }}
              disabled={updateMutation.isPending}
            >
              Edit
            </Button>
            <Button
              variant="outlined"
              color="error"
              onClick={() => deleteMutation.mutate(tag.id)}
              sx={{ ml: 2 }}
              disabled={deleteMutation.isPending}
            >
              Delete
            </Button>
          </Box>
        ))}
        {deleteMutation.error && <Typography color="error">{deleteMutation.error.message}</Typography>}
        {updateMutation.error && <Typography color="error">{updateMutation.error.message}</Typography>}
      </Box>

      {/* Edit Tag Dialog */}
      <Dialog open={!!editTag} onClose={handleCancelEdit}>
        <DialogTitle>Edit Tag</DialogTitle>
        <DialogContent>
          <TextField
            label="Tag Name"
            value={editTag?.name || ''}
            onChange={(e) => setEditTag((prev) => prev ? { ...prev, name: e.target.value } : null)}
            sx={{ mb: 2, mt: 1 }}
            fullWidth
            required
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCancelEdit}>Cancel</Button>
          <Button onClick={handleSaveEdit} variant="contained" disabled={updateMutation.isPending}>
            Save
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default AdminDashboard;