import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Box, Typography, Table, TableBody, TableCell, TableHead, TableRow, Button, Select, MenuItem, Input, Dialog, DialogTitle, DialogContent, DialogActions, FormControl, InputLabel } from '@mui/material';
import { getCallTasks, createCallTask, updateCallTask, type CreateCallTaskRequest, type CallTask } from '../../api/callTasks';
import { getTags, type Tag } from '../../api/callTasks';
import { useQueryClient } from '@tanstack/react-query';
import { getCallRecord, updateCallRecordsTags, type CallRecord } from '../../api/callRecords';

interface CallTaskListProps {
  callRecordId: string;
}

const CallTaskList: React.FC<CallTaskListProps> = ({ callRecordId }) => {
  const queryClient = useQueryClient();

  const { data: callRecord, isLoading: callLoading, error: callError } = useQuery<CallRecord, Error>({
    queryKey: ['callRecords', callRecordId],
    queryFn: () => getCallRecord(callRecordId),
    enabled: !!callRecordId,
  });

  const { data: tasks = [], isLoading: tasksLoading, error: tasksError } = useQuery<CallTask[], Error>({
    queryKey: ['callTasks', callRecordId],
    queryFn: () => getCallTasks(callRecordId),
    enabled: !!callRecordId,
  });

  const { data: tags = [] } = useQuery<Tag[], Error>({
    queryKey: ['tags'],
    queryFn: getTags,
  });

  const createMutation = useMutation({
    mutationFn: (data: CreateCallTaskRequest) => createCallTask(data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['callTasks', callRecordId] }),
    onError: (error) => console.error('Create task error:', error),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: 'open' | 'in_progress' | 'completed' }) =>
      updateCallTask(id, { status }, 'status'),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['callTasks', callRecordId] }),
    onError: (error) => console.error('Update task error:', error),
  });

  const updateTagMutation = useMutation({
    mutationFn: ({ id, tagIds }: { id: string; tagIds: string[] }) => {
      console.log('Updating call record tags:', { id, tagIds });
      return updateCallRecordsTags(id, tagIds);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['callRecords', callRecordId] });
      setOpenTagDialog(false);
    },
    onError: (error) => console.error('Update call record tags error:', error),
  });

  const [newTaskDescription, setNewTaskDescription] = useState('');
  const [openTagDialog, setOpenTagDialog] = useState<boolean>(false);
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>(callRecord?.tagIds || []);

  const handleCreateTask = () => {
    if (newTaskDescription.trim()) {
      console.log('Creating task with:', { name: newTaskDescription, callRecordId });
      createMutation.mutate({ name: newTaskDescription, callRecordId });
      setNewTaskDescription('');
    } else {
      console.warn('Task description is empty or invalid');
    }
  };

  const handleStatusChange = (taskId: string, status: 'open' | 'in_progress' | 'completed') => {
    console.log('Updating task status:', { taskId, status });
    updateMutation.mutate({ id: taskId, status });
  };


  const handleSaveTags = () => {
    console.log('Saving tags for call record:', { callRecordId, tagIds: selectedTagIds });
    updateTagMutation.mutate({ id: callRecordId, tagIds: selectedTagIds });
  };

  const isLoading = callLoading || tasksLoading;
  const error = callError || tasksError;

  if (isLoading) return <Typography>Loading tasks...</Typography>;
  if (error) return <Typography color="error">Error loading tasks: {error.message}</Typography>;

  return (
    <Box sx={{ mt: 2 }}>
      <Typography variant="h6" gutterBottom>
        Tasks for Call Record: {callRecord?.title || callRecordId}
      </Typography>

      <Box sx={{ mb: 2, display: 'flex', alignItems: 'center' }}>
        <Input
          value={newTaskDescription}
          onChange={(e) => setNewTaskDescription(e.target.value)}
          placeholder="Enter the task"
          sx={{ mr: 2 }}
        />
        <Button variant="contained" onClick={handleCreateTask} disabled={createMutation.isPending}>
          Add Task
        </Button>


      </Box>

      {/* Error messages */}
      {createMutation.error && <Typography color="error">{createMutation.error.message}</Typography>}
      {updateMutation.error && <Typography color="error">{updateMutation.error.message || 'Update failed'}</Typography>}
      {updateTagMutation.error && <Typography color="error">{updateTagMutation.error.message || 'Tag update failed'}</Typography>}

      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Task</TableCell>
            <TableCell>Status</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {tasks.map((task) => (
            <TableRow key={task.id}>
              <TableCell>{task.name || 'No name'}</TableCell>
              <TableCell>
                <Select
                  value={task.status || 'in_progress'}
                  onChange={(e) => handleStatusChange(task.id, e.target.value as 'open' | 'in_progress' | 'completed')}
                  disabled={updateMutation.isPending}
                >
                  <MenuItem value="open">Open</MenuItem>
                  <MenuItem value="in_progress">In Progress</MenuItem>
                  <MenuItem value="completed">Completed</MenuItem>
                </Select>
              </TableCell>
            </TableRow>
          ))}
          {tasks.length === 0 && (
            <TableRow>
              <TableCell colSpan={2}>No tasks found.</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      {/* Tag Assignment Dialog */}
      {openTagDialog && (
        <Dialog open={openTagDialog} onClose={() => setOpenTagDialog(false)}>
          <DialogTitle>Assign Tags to Call Record</DialogTitle>
          <DialogContent>
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel>Tags</InputLabel>
              <Select
                multiple
                value={selectedTagIds}
                onChange={(e) => {
                  setSelectedTagIds(e.target.value as string[]);
                  console.log('Selected tag IDs:', e.target.value);
                }}
                renderValue={(selected) => selected.map(id => tags.find(t => t.id === id)?.name || id).join(', ')}
                disabled={updateTagMutation.isPending}
              >
                {tags.map((tag) => (
                  <MenuItem key={tag.id} value={tag.id}>
                    {tag.name} ({tag.description || 'No description'})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenTagDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveTags} variant="contained" disabled={updateTagMutation.isPending}>
              Save
            </Button>
          </DialogActions>
        </Dialog>
      )}
    </Box>
  );
};

export default CallTaskList;