import React, { useState } from 'react';
import { TextField, Button, Box } from '@mui/material';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { createCallTask } from '../../api/callTasks';

interface CallTaskFormProps {
  callRecordId: string;
  onClose: () => void;
}

const CallTaskForm: React.FC<CallTaskFormProps> = ({ callRecordId, onClose }) => {
  const queryClient = useQueryClient();
  const [taskName, setTaskName] = useState('');
  const [error, setError] = useState<string | null>(null);

  const mutation = useMutation({
    mutationFn: (data: { name: string; status: string }) => createCallTask(callRecordId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['callTasks', callRecordId] });
      onClose();
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskName.trim()) {
      setError('Task name is required');
      return;
    }
    try {
      await mutation.mutate({ name: taskName.trim(), status: 'open' });
      setTaskName('');
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Failed to create task');
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit}>
      <TextField
        label="Task Name"
        fullWidth
        margin="normal"
        value={taskName}
        onChange={(e) => setTaskName(e.target.value)}
        error={!!error}
        helperText={error}
      />
      <Button type="submit" variant="contained" disabled={mutation.isPending} sx={{ mt: 2 }}>
        Create
      </Button>
    </Box>
  );
};

export default CallTaskForm;