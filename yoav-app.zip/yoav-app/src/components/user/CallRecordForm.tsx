import React, { useState } from 'react';
import { Box, Typography, Button, TextField, Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import { useMutation, useQuery } from '@tanstack/react-query';
import { createCallRecord, updateCallRecord } from '../../api/callRecords';
import { getTags } from '../../api/tags';
import type { Tag } from '../../sevices/authService';

interface CallRecordFormProps {
  record?: { id: string; title: string; tagIds?: string[] } | null;
  onClose: () => void;
  onSave: () => void;
}

const CallRecordForm: React.FC<CallRecordFormProps> = ({ record, onClose, onSave }) => {
  const [title, setTitle] = useState(record?.title || '');
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>(record?.tagIds || []);

  const { data: tags = [] } = useQuery<Tag[]>({
    queryKey: ['tags'],
    queryFn: getTags,
  });

  const mutation = useMutation({
    mutationFn: record?.id
      ? (data: { title: string; description?: string; callerName?: string; callerPhone?: string; tagIds?: string[] }) =>
        updateCallRecord(record.id, data)
      : (data: { title: string; description?: string; callerName?: string; callerPhone?: string; tagIds?: string[] }) =>
        createCallRecord(data),
    onSuccess: () => {
      onSave();
      onClose();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      alert('Title is required');
      return;
    }
    const data = {
      title,
      tagIds: selectedTagIds.length > 0 ? selectedTagIds : undefined,
    };
    mutation.mutate(data);
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom>{record ? 'Edit Call Record' : 'Create New Call Record'}</Typography>
      <form onSubmit={handleSubmit}>
        <TextField
          label="Title *"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          sx={{ mb: 2, mr: 2 }}
        />

        <FormControl sx={{ mb: 2, mr: 2, minWidth: 200 }}>
          <InputLabel>Tags</InputLabel>
          <Select
            multiple
            value={selectedTagIds}
            onChange={(e) => setSelectedTagIds(e.target.value as string[])}
            renderValue={(selected) => selected.map(id => tags.find(t => t.id === id)?.name || id).join(', ')}
          >
            {tags.map((tag) => (
              <MenuItem key={tag.id} value={tag.id}>
                {tag.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <Button type="submit" variant="contained" disabled={mutation.isPending}>
          {record ? 'Save' : 'Create'}
        </Button>
        {mutation.error && <Typography color="error" sx={{ mt: 2 }}>{mutation.error.message}</Typography>}
      </form>
    </Box>
  );
};

export default CallRecordForm;