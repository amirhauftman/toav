import React, { useState } from 'react';
import {
  Table, TableBody, TableCell, TableHead, TableRow, Button,
  Dialog, DialogTitle, DialogContent, DialogActions, FormControl,
  InputLabel, Select, MenuItem, TablePagination
} from '@mui/material';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getCallRecords, updateCallRecordsTags, type CallRecord } from '../../api/callRecords';
import { getTags, type Tag } from '../../api/callTasks';

interface CallRecordListProps {
  onSelectCallRecord: (id: string) => void;
  onEditCallRecord: (record: CallRecord) => void;
  statusFilter?: string;
}

interface CallRecordsResponse {
  items: CallRecord[];
  total: number;
}

const CallRecordList: React.FC<CallRecordListProps> = ({ onSelectCallRecord, onEditCallRecord, statusFilter }) => {
  const queryClient = useQueryClient();

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [openTagDialog, setOpenTagDialog] = useState(false);
  const [selectedRecordId, setSelectedRecordId] = useState<string | null>(null);
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>([]);

  const { data: callData = { items: [], total: 0 }, isLoading } = useQuery<CallRecordsResponse>({
    queryKey: ['callRecords', statusFilter, page, rowsPerPage],
    queryFn: () => getCallRecords(page + 1, rowsPerPage, statusFilter),
    keepPreviousData: true,
  });

  const { data: tags = [] } = useQuery<Tag[]>({
    queryKey: ['tags'],
    queryFn: getTags,
  });

  const updateTagMutation = useMutation({
    mutationFn: ({ id, tagIds }: { id: string; tagIds: string[] }) => updateCallRecordsTags(id, tagIds),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['callRecords', statusFilter, page, rowsPerPage] });
      setOpenTagDialog(false);
      setSelectedRecordId(null);
    },
  });

  const getTagNames = (tags?: Tag[]) => tags?.map(tag => tag.name).join(', ') || 'No tags';

  const handleAssignTags = (recordId: string) => {
    const record = callData.items.find(r => r.id === recordId);
    setSelectedTagIds(record?.tagIds ?? []);
    setSelectedRecordId(recordId);
    setOpenTagDialog(true);
  };

  const handleSaveTags = () => {
    if (selectedRecordId) {
      updateTagMutation.mutate({ id: selectedRecordId, tagIds: selectedTagIds });
    }
  };

  const handleChangePage = (_event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Title</TableCell>
            <TableCell>All Tags</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {callData.items.map(record => (
            <TableRow key={record.id} hover onClick={() => onSelectCallRecord(record.id)} style={{ cursor: 'pointer' }}>
              <TableCell>{record.title}</TableCell>
              <TableCell>{getTagNames(record.tags)}</TableCell>
              <TableCell>
                <Button onClick={e => { e.stopPropagation(); onEditCallRecord(record); }} sx={{ mr: 1 }}>
                  Edit
                </Button>
                <Button onClick={e => { e.stopPropagation(); handleAssignTags(record.id); }} variant="contained">
                  Assign Tags
                </Button>
              </TableCell>
            </TableRow>
          ))}
          {!callData.items.length && (
            <TableRow>
              <TableCell colSpan={3}>No call records found.</TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <TablePagination
        component="div"
        count={callData.total}
        page={page}
        onPageChange={handleChangePage}
        rowsPerPage={rowsPerPage}
        onRowsPerPageChange={handleChangeRowsPerPage}
      />

      <Dialog open={openTagDialog} onClose={() => setOpenTagDialog(false)}>
        <DialogTitle>Assign Tags to Call Record</DialogTitle>
        <DialogContent>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Tags</InputLabel>
            <Select
              multiple
              value={selectedTagIds}
              onChange={e => setSelectedTagIds(e.target.value as string[])}
              renderValue={selected => selected.map(id => tags.find(t => t.id === id)?.name || id).join(', ')}
            >
              {tags.map(tag => (
                <MenuItem key={tag.id} value={tag.id}>
                  {tag.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenTagDialog(false)}>Cancel</Button>
          <Button onClick={handleSaveTags} variant="contained">Save</Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default CallRecordList;
