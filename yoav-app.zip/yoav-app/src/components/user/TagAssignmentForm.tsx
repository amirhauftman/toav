import React, { useState, useEffect } from 'react';
import { Box, Typography, Button, Select, MenuItem, FormControl, InputLabel, CircularProgress } from '@mui/material';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getTags } from '../../api/tags';
import { getCallRecord, updateCallRecord, type CallRecord } from '../../api/callRecords';
import type { Tag } from '../../sevices/authService';

interface TagAssignmentFormProps {
    callRecordId: string;
    onClose: () => void;
}

const TagAssignmentForm: React.FC<TagAssignmentFormProps> = ({ callRecordId, onClose }) => {
    const queryClient = useQueryClient();
    const [selectedTagIds, setSelectedTagIds] = useState<string[]>([]);

    const { data: tags = [], isLoading: tagsLoading } = useQuery<Tag[]>({
        queryKey: ['tags'],
        queryFn: getTags,
    });

    const { data: callRecord, isLoading: callRecordLoading } = useQuery<CallRecord, Error>({
        queryKey: ['callRecord', callRecordId],
        queryFn: () => getCallRecord(callRecordId),
        enabled: !!callRecordId,
    });

    const updateMutation = useMutation({
        mutationFn: (data: { tagIds: string[] }) => updateCallRecord(callRecordId, data),
        onSuccess: () => {
            console.log('Tag assignment success for callRecordId:', callRecordId);
            queryClient.invalidateQueries({ queryKey: ['callRecord', callRecordId] }); // Fixed syntax
            queryClient.invalidateQueries({ queryKey: ['callRecords'] }); // Fixed syntax
            onClose();
        },
        onError: (error) => console.error('Tag assignment error:', error),
    });

    useEffect(() => {
        if (callRecord?.tagIds) {
            setSelectedTagIds(callRecord.tagIds);
        } else {
            setSelectedTagIds([]);
        }
    }, [callRecord]);

    const handleSave = () => {
        console.log('Saving tag assignments:', { callRecordId, tagIds: selectedTagIds });
        updateMutation.mutate({ tagIds: selectedTagIds });
    };

    if (tagsLoading || callRecordLoading) return <CircularProgress />;

    return (
        <Box>
            <Typography variant="h6" gutterBottom>Assign Tags to Call Record</Typography>
            <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel>Tags</InputLabel>
                <Select
                    multiple
                    value={selectedTagIds}
                    onChange={(e) => setSelectedTagIds(e.target.value as string[])}
                    renderValue={(selected) => selected.map(id => tags.find(t => t.id === id)?.name || id).join(', ')}
                    disabled={updateMutation.isPending}
                >
                    {tags.map((tag) => (
                        <MenuItem key={tag.id} value={tag.id}>
                            {tag.name} ({tag.description || 'No description'})
                        </MenuItem>
                    ))}
                </Select>
            </FormControl>
            {updateMutation.error && <Typography color="error">{updateMutation.error.message}</Typography>}
            <Button onClick={onClose} sx={{ mr: 2 }}>
                Cancel
            </Button>
            <Button onClick={handleSave} variant="contained" disabled={updateMutation.isPending}>
                Save
            </Button>
        </Box>
    );
};

export default TagAssignmentForm;