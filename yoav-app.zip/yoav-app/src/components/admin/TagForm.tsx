import { useState } from 'react';
import { Button, TextField, Box, Typography } from '@mui/material';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { createTag, updateTag } from '../../api/tags';

interface TagFormProps {
  tag?: { id: string; name: string; };
  onClose: () => void;
}

const TagForm: React.FC<TagFormProps> = ({ tag, onClose }) => {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({ name: tag?.name || '' });
  const isEdit = !!tag;

  const mutation = useMutation({
    mutationFn: isEdit ? (data: { name?: string; }) => updateTag(tag.id, data) : createTag,
    onSuccess: () => {
      queryClient.invalidateQueries(['tags']);
      onClose();
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutation.mutate(formData);
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
      <Typography variant="h6">{isEdit ? 'Edit Tag' : 'Create Tag'}</Typography>
      <TextField
        label="Name"
        fullWidth
        value={formData.name}
        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
        required
        sx={{ mb: 2 }}
      />
      <Button type="submit" variant="contained" disabled={mutation.isPending}>
        {isEdit ? 'Update' : 'Create'}
      </Button>
      <Button onClick={onClose} sx={{ ml: 2 }}>Cancel</Button>
    </Box>
  );
};

export default TagForm;