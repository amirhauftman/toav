import { useQuery } from '@tanstack/react-query';
import { Box, Typography, Button, List, ListItem, ListItemText } from '@mui/material';
import { deleteTag, getTags } from '../../api/tags';
import TagForm from './TagForm';
import { useState } from 'react';

const TagList: React.FC = () => {
  const { data: tags, isLoading, error } = useQuery(['tags'], getTags);
  const [openForm, setOpenForm] = useState(false);
  const [selectedTag, setSelectedTag] = useState<{ id: string; name: string; } | null>(null);

  if (isLoading) return <Typography>Loading...</Typography>;
  if (error) return <Typography color="error">Error loading tags</Typography>;

  return (
    <Box>
      <Typography variant="h5" gutterBottom>Tags</Typography>
      <Button variant="contained" onClick={() => { setSelectedTag(null); setOpenForm(true); }} sx={{ mb: 2 }}>
        Create Tag
      </Button>
      {openForm && <TagForm tag={selectedTag} onClose={() => setOpenForm(false)} />}
      <List>
        {tags?.map((tag) => (
          <ListItem key={tag.id} secondaryAction={
            <>
              <Button onClick={() => { setSelectedTag(tag); setOpenForm(true); }}>Edit</Button>
              <Button onClick={() => deleteTag(tag.id)}>Delete</Button>
            </>
          }>
            <ListItemText primary={tag.name} />
          </ListItem>
        ))}
      </List>
    </Box>
  );
};

export default TagList;