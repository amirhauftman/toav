import axios from 'axios';
import { authService } from '../sevices/authService';

export interface SuggestedTask {
  id: string;
  description: string;
}

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
});

api.interceptors.request.use(
  (config) => {
    const token = authService.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log('Authorization header set for suggested-tasks:', `Bearer ${token}`);
    } else {
      console.warn('No token available for suggested-tasks request');
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export const getSuggestedTasks = async (): Promise<SuggestedTask[]> => {
  try {
    const response = await api.get('/suggested-tasks');
    console.log('Suggested tasks response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Get suggested tasks error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to fetch suggested tasks');
  }
};