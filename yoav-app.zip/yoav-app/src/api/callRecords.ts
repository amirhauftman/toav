import axios from 'axios';
import { authService } from '../sevices/authService';

export interface CallRecord {
  id: string;
  title: string;
  status: 'open' | 'in_progress' | 'completed' | 'closed';
  // description?: string;
  createdAt: Date;
  updatedAt: Date;
  assignedUserId?: string;
  tagIds?: string[];
  tags?: Tag[];
  tasks?: CallTask[];
}

export interface Tag {
  id: string;
  name: string;
  description?: string;
}

export interface CallTask {
  id: string;
  description: string;
  completed: boolean;
  callRecordId: string;
}

export interface CreateCallRecordRequest {
  title: string;
  description?: string;
  tagIds?: string[];
  assignedUserId?: string;
}

export interface UpdateCallRecordRequest {
  title?: string;
  description?: string;
  tagIds?: string[];
  assignedUserId?: string;
  status?: 'open' | 'in_progress' | 'completed' | 'closed';
}

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
});

api.interceptors.request.use(
  (config) => {
    const token = authService.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log('Authorization header set for call records:', `Bearer ${token}`);
    } else {
      console.warn('No token available for call records request');
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export const getCallRecords = async (page: number, limit: number, statusFilter?: string): Promise<{ items: CallRecord[]; total: number }> => {
  try {
    const response = await api.get('/call-records', { params: { page, limit, status: statusFilter } });
    console.log('Call records response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Get call records error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to fetch call records');
  }
};

export const getCallRecord = async (id: string): Promise<CallRecord> => {
  try {
    const response = await api.get(`/call-records/${id}`);
    console.log('Call record response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Get call record error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to fetch call record');
  }
};

export const createCallRecord = async (data: CreateCallRecordRequest): Promise<CallRecord> => {
  try {
    console.log('Creating call record with data:', data);
    const response = await api.post('/call-records', data);
    return response.data;
  } catch (err: any) {
    console.error('Create call record error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to create call record');
  }
};

export const updateCallRecord = async (id: string, data: UpdateCallRecordRequest): Promise<CallRecord> => {
  try {
    console.log('Updating call record with data:', data);
    const response = await api.patch(`/call-records/${id}`, data);
    console.log('Update call record response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Update call record error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to update call record');
  }
};

export const updateCallRecordsTags = async (id: string, tagIds: string[]): Promise<CallRecord> => {
  try {
    console.log('Updating call record tags with IDs:', tagIds);
    const response = await api.patch(`/call-records/${id}/tags`, { tagIds });
    console.log('Update call record tags response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Update call record tags error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to update call record tags');
  }
}

export const deleteCallRecord = async (id: string): Promise<void> => {
  try {
    await api.delete(`/call-records/${id}`);
  } catch (err: any) {
    console.error('Delete call record error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to delete call record');
  }
};