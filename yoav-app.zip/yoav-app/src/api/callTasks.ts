import axios from 'axios';
import { authService } from '../sevices/authService';

export interface CallTask {
  id: string;
  name: string;
  description?: string;
  status: 'open' | 'in_progress' | 'completed';
  createdAt: Date;
  updatedAt: Date;
  callRecordId: string;
  suggestedTaskId?: string;
  tagIds?: string[];
}

export interface CreateCallTaskRequest {
  name: string;
  description?: string;
  callRecordId: string;
  suggestedTaskId?: string;
  tagIds?: string[];
}

export interface UpdateCallTaskRequest {
  name?: string;
  description?: string;
  tagIds?: string[];
}

export interface UpdateTaskStatusRequest {
  status: 'open' | 'in_progress' | 'completed';
}

export interface Tag {
  id: string;
  name: string;
  description?: string;
}

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
});

api.interceptors.request.use(
  (config) => {
    const token = authService.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log('Authorization header set for call tasks:', `Bearer ${token}`);
    } else {
      console.warn('No token available for call tasks request');
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export const getCallTasks = async (callRecordId: string): Promise<CallTask[]> => {
  try {
    const response = await api.get('/call-tasks', { params: { callRecordId } });
    console.log('Call tasks response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Get call tasks error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to fetch call tasks');
  }
};

export const getTags = async (): Promise<Tag[]> => {
  try {
    const response = await api.get('/tags');
    console.log('Tags response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Get tags error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to fetch tags');
  }
};

export const createCallTask = async (data: CreateCallTaskRequest): Promise<CallTask> => {
  try {
    console.log('Creating call task with data:', data);
    const response = await api.post('/call-tasks', data);
    return response.data;
  } catch (err: any) {
    console.error('Create call task error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to create call task');
  }
};

export const updateCallTask = async (id: string, data: UpdateCallTaskRequest | UpdateTaskStatusRequest, endpoint: string = ''): Promise<CallTask> => {
  try {
    const url = endpoint ? `/call-tasks/${id}/${endpoint}` : `/call-tasks/${id}`;
    console.log(`Updating call task with data:`, { id, data, url });
    const response = await api.patch(url, data);
    console.log('Update call task response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Update call task error:', err.response?.data || err.message);
    throw new Error(err.response?.data?.message || 'Failed to update call task');
  }
};

export const deleteCallTask = async (id: string): Promise<void> => {
  try {
    await api.delete(`/call-tasks/${id}`);
  } catch (err: any) {
    console.error('Delete call task error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to delete call task');
  }
};