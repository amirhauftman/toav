import axios from 'axios';
import { authService } from '../sevices/authService';

export interface Tag {
  id: string;
  name: string;
}

const api = axios.create({
  baseURL: 'http://localhost:3001/api',
});

api.interceptors.request.use(
  (config) => {
    const token = authService.getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log('Authorization header set for tags:', `Bearer ${token}`);
    } else {
      console.warn('No token available for tags request');
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export const getTags = async (): Promise<Tag[]> => {
  try {
    const response = await api.get('/tags');
    console.log('Tags response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Get tags error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to fetch tags');
  }
};

export const createTag = async (data: { name: string; }): Promise<Tag> => {
  try {
    console.log('Creating tag with data:', data);
    const response = await api.post('/tags', data);
    return response.data;
  } catch (err: any) {
    console.error('Create tag error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to create tag');
  }
};

export const updateTag = async (id: string, name: string): Promise<Tag> => {
  try {
    console.log('Updating tag with data:', { id, name });
    const payload = { name };
    const response = await api.patch(`/tags/${id}`, payload);
    console.log('Update tag response:', response.data);
    return response.data;
  } catch (err: any) {
    console.error('Update tag error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to update tag');
  }
};

export const deleteTag = async (id: string): Promise<void> => {
  try {
    await api.delete(`/tags/${id}`);
  } catch (err: any) {
    console.error('Delete tag error:', err.response?.data?.message || err.message);
    throw new Error(err.response?.data?.message || 'Failed to delete tag');
  }
};