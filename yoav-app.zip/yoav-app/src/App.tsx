import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import UserDashboard from './pages/UserDashboard';
import Register from './pages/Register';
import { authService } from './sevices/authService';

const App: React.FC = () => {
  const [user, setUser] = useState(authService.getUser());

  useEffect(() => {
    const checkAuth = () => setUser(authService.getUser());
    checkAuth();
    const interval = setInterval(checkAuth, 1000); // Poll every second
    return () => clearInterval(interval);
  }, []);

  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route
          path="/login"
          element={!user ? <Login /> : user.role === 'admin' ? <Navigate to="/admin" replace /> : <Navigate to="/dashboard" replace />}
        />
        <Route
          path="/register"
          element={!user ? <Register /> : user.role === 'admin' ? <Navigate to="/admin" replace /> : <Navigate to="/dashboard" replace />}
        />

        {/* Protected Routes */}
        <Route
          path="/admin"
          element={user && user.role === 'admin' ? <AdminDashboard /> : <Navigate to="/login" replace />}
        />
        <Route
          path="/dashboard"
          element={user && user.role !== 'admin' ? <UserDashboard /> : <Navigate to="/login" replace />}
        />

        {/* Default Redirect */}
        <Route path="/" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;